<?php

  # needs to include the needed pages
  if(isset($_GET['page'])) {
    include($_GET['page']);
  }

?>
