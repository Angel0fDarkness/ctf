<?php

if(isset($_POST['name'])) {

    $arr = array($_POST['name'], $_POST['food']);
    $data = serialize($arr);
    echo $data;
}

if(isset($_GET['invite'])) {
    $invite_content = $_GET['invite'];
    $invite_name = md5($invite_content);
    file_put_contents('../invitation/'.$invite_name, $invite_content);
    die();
}


;