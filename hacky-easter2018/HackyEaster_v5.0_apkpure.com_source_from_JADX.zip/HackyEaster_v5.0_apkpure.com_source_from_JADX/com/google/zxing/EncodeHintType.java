package com.google.zxing;

public enum EncodeHintType {
    ERROR_CORRECTION,
    CHARACTER_SET,
    MARGIN,
    PDF417_COMPACT,
    PDF417_COMPACTION,
    PDF417_DIMENSIONS
}
