package com.google.zxing.client.android;

import ps.hacking.hackyeaster.android.C0089R;

public final class C0037R {

    public static final class attr {
        public static final int zxing_framing_rect_height = 2130771968;
        public static final int zxing_framing_rect_width = 2130771969;
        public static final int zxing_possible_result_points = 2130771970;
        public static final int zxing_preview_scaling_strategy = 2130771971;
        public static final int zxing_result_view = 2130771972;
        public static final int zxing_scanner_layout = 2130771973;
        public static final int zxing_use_texture_view = 2130771974;
        public static final int zxing_viewfinder_laser = 2130771975;
        public static final int zxing_viewfinder_mask = 2130771976;
    }

    public static final class color {
        public static final int zxing_custom_possible_result_points = 2130837515;
        public static final int zxing_custom_result_view = 2130837516;
        public static final int zxing_custom_viewfinder_laser = 2130837517;
        public static final int zxing_custom_viewfinder_mask = 2130837518;
        public static final int zxing_possible_result_points = 2130837519;
        public static final int zxing_result_view = 2130837520;
        public static final int zxing_status_text = 2130837521;
        public static final int zxing_transparent = 2130837522;
        public static final int zxing_viewfinder_laser = 2130837523;
        public static final int zxing_viewfinder_mask = 2130837524;
    }

    public static final class id {
        public static final int centerCrop = 2131034114;
        public static final int fitCenter = 2131034118;
        public static final int fitXY = 2131034119;
        public static final int zxing_back_button = 2131034131;
        public static final int zxing_barcode_scanner = 2131034132;
        public static final int zxing_barcode_surface = 2131034133;
        public static final int zxing_camera_error = 2131034134;
        public static final int zxing_decode = 2131034135;
        public static final int zxing_decode_failed = 2131034136;
        public static final int zxing_decode_succeeded = 2131034137;
        public static final int zxing_possible_result_points = 2131034138;
        public static final int zxing_prewiew_size_ready = 2131034139;
        public static final int zxing_status_view = 2131034140;
        public static final int zxing_viewfinder_view = 2131034141;
    }

    public static final class layout {
        public static final int zxing_barcode_scanner = 2131099651;
        public static final int zxing_capture = 2131099652;
    }

    public static final class raw {
        public static final int zxing_beep = 2131165185;
    }

    public static final class string {
        public static final int zxing_app_name = 2131230723;
        public static final int zxing_button_ok = 2131230724;
        public static final int zxing_msg_camera_framework_bug = 2131230725;
        public static final int zxing_msg_default_status = 2131230726;
    }

    public static final class style {
        public static final int zxing_CaptureTheme = 2131296258;
    }

    public static final class styleable {
        public static final int[] zxing_camera_preview = new int[]{C0089R.attr.zxing_framing_rect_height, C0089R.attr.zxing_framing_rect_width, C0089R.attr.zxing_preview_scaling_strategy, C0089R.attr.zxing_use_texture_view};
        public static final int zxing_camera_preview_zxing_framing_rect_height = 0;
        public static final int zxing_camera_preview_zxing_framing_rect_width = 1;
        public static final int zxing_camera_preview_zxing_preview_scaling_strategy = 2;
        public static final int zxing_camera_preview_zxing_use_texture_view = 3;
        public static final int[] zxing_finder = new int[]{C0089R.attr.zxing_possible_result_points, C0089R.attr.zxing_result_view, C0089R.attr.zxing_viewfinder_laser, C0089R.attr.zxing_viewfinder_mask};
        public static final int zxing_finder_zxing_possible_result_points = 0;
        public static final int zxing_finder_zxing_result_view = 1;
        public static final int zxing_finder_zxing_viewfinder_laser = 2;
        public static final int zxing_finder_zxing_viewfinder_mask = 3;
        public static final int[] zxing_view = new int[]{C0089R.attr.zxing_scanner_layout};
        public static final int zxing_view_zxing_scanner_layout = 0;
    }
}
