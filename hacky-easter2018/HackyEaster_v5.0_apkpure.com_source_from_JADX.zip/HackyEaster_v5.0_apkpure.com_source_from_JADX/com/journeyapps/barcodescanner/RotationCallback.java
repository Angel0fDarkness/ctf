package com.journeyapps.barcodescanner;

public interface RotationCallback {
    void onRotationChanged(int i);
}
